package com.example.block01;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.style.BackgroundColorSpan;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button bluebtn, pinkbtn, oranbtn, graybtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bluebtn = findViewById(R.id.invi);
        oranbtn = findViewById(R.id.appear);
        graybtn = findViewById(R.id.remove);

        pinkbtn = new Button(getApplicationContext());
        pinkbtn.setTextColor(Color.BLACK);
        pinkbtn.setBackgroundColor(Color.parseColor(("#FD9BF3")));
        pinkbtn.setText("Read");


        RelativeLayout rl_mainScreen = (RelativeLayout) findViewById(R.id.relativeLayout_mainScreen);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT
        );

        params.addRule(RelativeLayout.BELOW, bluebtn);
        rl_mainScreen.addview(pinkbtn);

        bluebtn.setOnClickListener(this);
        pinkbtn.setOnClickListener(this);
        oranbtn.setOnClickListener(this);
    }
    public void toDo(View v){
        if (v.equals(bluebtn))
            v.setVisibility(View.INVISIBLE);
        if (v.equals(pinkbtn))
            Toast.makeText(this, "Read Complete", Toast.LENGTH_SHORT).show();
        if (v.equals(oranbtn))
            bluebtn.setVisibility(View.VISIBLE);

    }

    public void onClick(View v){
        toDo(v);
    }

}

